﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using Microsoft.Win32;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        bool createdNew;
        using (var mutex = new Mutex(true, @"Local\MXBackspaceHold_SingleInstance", out createdNew))
        {
            if (!createdNew)
            {
                MessageBox.Show("MXBackspaceHold 已经在后台运行。", "MXBackspaceHold",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new TrayContext());
        }
    }
}

internal sealed class TrayContext : ApplicationContext
{
    private const int WH_MOUSE_LL = 14;
    private const int WM_XBUTTONDOWN = 0x020B;
    private const int WM_XBUTTONUP   = 0x020C;
    private const ushort VK_BACK = 0x08;

    private const uint INPUT_KEYBOARD = 1;
    private const uint KEYEVENTF_KEYUP = 0x0002;

    private const uint SPI_GETKEYBOARDSPEED = 0x000A;
    private const uint SPI_GETKEYBOARDDELAY = 0x0016;

    private const string AppRegPath = @"Software\MXBackspaceHold";
    private const string RunRegPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
    private const string RunValueName = "MXBackspaceHold";

    private readonly NotifyIcon trayIcon;
    private readonly ToolStripMenuItem enabledItem;
    private readonly ToolStripMenuItem xButton1Item;
    private readonly ToolStripMenuItem xButton2Item;
    private readonly ToolStripMenuItem startupItem;
    private readonly ToolStripMenuItem detectedItem;

    private readonly ToolStripMenuItem speedMenu;
    private readonly ToolStripMenuItem delayMenu;

    private readonly ToolStripMenuItem speedWindowsItem;
    private readonly ToolStripMenuItem speed30Item;
    private readonly ToolStripMenuItem speed25Item;
    private readonly ToolStripMenuItem speed20Item;
    private readonly ToolStripMenuItem speed15Item;

    private readonly ToolStripMenuItem delayWindowsItem;
    private readonly ToolStripMenuItem delay400Item;
    private readonly ToolStripMenuItem delay300Item;
    private readonly ToolStripMenuItem delay250Item;

    private readonly LowLevelMouseProc hookProc;
    private IntPtr hookHandle = IntPtr.Zero;

    private volatile bool enabled = true;
    private volatile bool held = false;
    private volatile int selectedButton = 2; // 1=XButton1, 2=XButton2

    // 0 = 跟随 Windows；否则为固定毫秒值
    private volatile int repeatIntervalOverride = 0;
    private volatile int repeatDelayOverride = 0;

    private System.Threading.Timer repeatTimer;

    public TrayContext()
    {
        LoadSettings();

        hookProc = HookCallback;
        hookHandle = SetWindowsHookEx(WH_MOUSE_LL, hookProc, GetModuleHandle(null), 0);
        if (hookHandle == IntPtr.Zero)
        {
            MessageBox.Show(
                "无法安装鼠标监听。\r\n\r\n请退出后重新运行；如果目标程序以管理员身份运行，也可以尝试以管理员身份运行本程序。",
                "MXBackspaceHold",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            ExitThread();
            return;
        }

        repeatTimer = new System.Threading.Timer(RepeatBackspace, null, Timeout.Infinite, Timeout.Infinite);

        enabledItem = new ToolStripMenuItem("启用连续退格");
        enabledItem.Checked = enabled;
        enabledItem.CheckOnClick = true;
        enabledItem.Click += delegate
        {
            enabled = enabledItem.Checked;
            if (!enabled)
                StopRepeating();
            SaveSettings();
        };

        xButton1Item = new ToolStripMenuItem("使用 XButton1（通常是“后退”）");
        xButton2Item = new ToolStripMenuItem("使用 XButton2（通常是“前进”）");

        xButton1Item.Click += delegate { SelectButton(1); };
        xButton2Item.Click += delegate { SelectButton(2); };

        detectedItem = new ToolStripMenuItem("最近检测到：尚未按侧键");
        detectedItem.Enabled = false;

        startupItem = new ToolStripMenuItem("开机自动启动");
        startupItem.Checked = IsStartupEnabled();
        startupItem.Click += delegate
        {
            try
            {
                SetStartupEnabled(!IsStartupEnabled());
                startupItem.Checked = IsStartupEnabled();
            }
            catch (Exception ex)
            {
                MessageBox.Show("修改开机启动失败：\r\n" + ex.Message,
                    "MXBackspaceHold", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        };

        speedMenu = new ToolStripMenuItem("重复速度");
        speedWindowsItem = new ToolStripMenuItem("跟随 Windows");
        speed30Item = new ToolStripMenuItem("快：30 ms / 次");
        speed25Item = new ToolStripMenuItem("更快：25 ms / 次");
        speed20Item = new ToolStripMenuItem("很快：20 ms / 次");
        speed15Item = new ToolStripMenuItem("极速：15 ms / 次");

        speedWindowsItem.Click += delegate { SetRepeatInterval(0); };
        speed30Item.Click += delegate { SetRepeatInterval(30); };
        speed25Item.Click += delegate { SetRepeatInterval(25); };
        speed20Item.Click += delegate { SetRepeatInterval(20); };
        speed15Item.Click += delegate { SetRepeatInterval(15); };

        speedMenu.DropDownItems.Add(speedWindowsItem);
        speedMenu.DropDownItems.Add(speed30Item);
        speedMenu.DropDownItems.Add(speed25Item);
        speedMenu.DropDownItems.Add(speed20Item);
        speedMenu.DropDownItems.Add(speed15Item);

        delayMenu = new ToolStripMenuItem("长按延迟");
        delayWindowsItem = new ToolStripMenuItem("跟随 Windows");
        delay400Item = new ToolStripMenuItem("400 ms");
        delay300Item = new ToolStripMenuItem("300 ms");
        delay250Item = new ToolStripMenuItem("250 ms");

        delayWindowsItem.Click += delegate { SetRepeatDelay(0); };
        delay400Item.Click += delegate { SetRepeatDelay(400); };
        delay300Item.Click += delegate { SetRepeatDelay(300); };
        delay250Item.Click += delegate { SetRepeatDelay(250); };

        delayMenu.DropDownItems.Add(delayWindowsItem);
        delayMenu.DropDownItems.Add(delay400Item);
        delayMenu.DropDownItems.Add(delay300Item);
        delayMenu.DropDownItems.Add(delay250Item);

        UpdateSpeedChecks();
        UpdateDelayChecks();

        var exitItem = new ToolStripMenuItem("退出");
        exitItem.Click += delegate { ExitThread(); };

        UpdateButtonChecks();

        var menu = new ContextMenuStrip();
        menu.Items.Add(enabledItem);
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add(xButton1Item);
        menu.Items.Add(xButton2Item);
        menu.Items.Add(detectedItem);
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add(speedMenu);
        menu.Items.Add(delayMenu);
        menu.Items.Add(startupItem);
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add(exitItem);

        trayIcon = new NotifyIcon();
        trayIcon.Icon = SystemIcons.Application;
        trayIcon.Text = "MXBackspaceHold";
        trayIcon.ContextMenuStrip = menu;
        trayIcon.Visible = true;
        trayIcon.DoubleClick += delegate
        {
            enabled = !enabled;
            enabledItem.Checked = enabled;
            if (!enabled)
                StopRepeating();
            SaveSettings();
            trayIcon.ShowBalloonTip(
                1200,
                "MXBackspaceHold",
                enabled ? "连续退格已启用" : "连续退格已暂停",
                ToolTipIcon.Info);
        };

        trayIcon.ShowBalloonTip(
            1800,
            "MXBackspaceHold 已启动",
            "短按删 1 个字；按住后按 Windows 键盘速度连续删除。右键托盘图标可暂停或退出。",
            ToolTipIcon.Info);
    }

    private void SelectButton(int button)
    {
        StopRepeating();
        selectedButton = button;
        UpdateButtonChecks();
        SaveSettings();
    }

    private void UpdateButtonChecks()
    {
        if (xButton1Item != null)
            xButton1Item.Checked = selectedButton == 1;
        if (xButton2Item != null)
            xButton2Item.Checked = selectedButton == 2;
    }

    private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0 && enabled &&
            (wParam == (IntPtr)WM_XBUTTONDOWN || wParam == (IntPtr)WM_XBUTTONUP))
        {
            MSLLHOOKSTRUCT data = (MSLLHOOKSTRUCT)Marshal.PtrToStructure(
                lParam, typeof(MSLLHOOKSTRUCT));

            int button = (int)((data.mouseData >> 16) & 0xFFFF);

            if (wParam == (IntPtr)WM_XBUTTONDOWN && (button == 1 || button == 2))
            {
                try
                {
                    if (detectedItem != null && detectedItem.GetCurrentParent() != null)
                    {
                        detectedItem.GetCurrentParent().BeginInvoke((MethodInvoker)delegate
                        {
                            detectedItem.Text = "最近检测到：XButton" + button;
                        });
                    }
                }
                catch { }
            }

            if (button == selectedButton)
            {
                if (wParam == (IntPtr)WM_XBUTTONDOWN)
                {
                    if (!held)
                    {
                        held = true;

                        // 像实体 Backspace：按下立即删一个
                        SendBackspace();

                        int delayMs = repeatDelayOverride > 0
                            ? repeatDelayOverride
                            : GetKeyboardRepeatDelayMs();

                        int intervalMs = repeatIntervalOverride > 0
                            ? repeatIntervalOverride
                            : GetKeyboardRepeatIntervalMs();

                        repeatTimer.Change(delayMs, intervalMs);
                    }
                }
                else
                {
                    StopRepeating();
                }

                // 拦截这个侧键，避免同时触发浏览器“前进/后退”
                return (IntPtr)1;
            }
        }

        return CallNextHookEx(hookHandle, nCode, wParam, lParam);
    }

    private void RepeatBackspace(object state)
    {
        if (enabled && held)
            SendBackspace();
    }

    private void StopRepeating()
    {
        held = false;
        if (repeatTimer != null)
            repeatTimer.Change(Timeout.Infinite, Timeout.Infinite);
    }

    private static int GetKeyboardRepeatDelayMs()
    {
        uint value;
        if (SystemParametersInfo(SPI_GETKEYBOARDDELAY, 0, out value, 0))
        {
            if (value > 3) value = 3;
            return (int)((value + 1) * 250); // Windows: 250/500/750/1000 ms
        }
        return 500;
    }

    private static int GetKeyboardRepeatIntervalMs()
    {
        uint speed;
        if (SystemParametersInfo(SPI_GETKEYBOARDSPEED, 0, out speed, 0))
        {
            if (speed > 31) speed = 31;

            // Windows 键盘速度约为 2.5 ~ 30 字符/秒
            double charsPerSecond = 2.5 + (27.5 * speed / 31.0);
            int interval = (int)Math.Round(1000.0 / charsPerSecond);
            if (interval < 20) interval = 20;
            return interval;
        }
        return 40;
    }

    private static void SendBackspace()
    {
        // 使用 keybd_event 避免旧版 .NET / x64 下 INPUT 联合体尺寸不一致的问题。
        // 对这个极简单键场景，它比手写 SendInput 结构体更稳。
        keybd_event((byte)VK_BACK, 0, 0, UIntPtr.Zero);
        keybd_event((byte)VK_BACK, 0, KEYEVENTF_KEYUP, UIntPtr.Zero);
    }

    private void SetRepeatInterval(int intervalMs)
    {
        repeatIntervalOverride = intervalMs;
        UpdateSpeedChecks();
        SaveSettings();

        // 如果当前正处于长按连删，立即应用新速度
        if (held && repeatTimer != null)
        {
            int delayMs = 1;
            int interval = repeatIntervalOverride > 0
                ? repeatIntervalOverride
                : GetKeyboardRepeatIntervalMs();

            repeatTimer.Change(delayMs, interval);
        }
    }

    private void SetRepeatDelay(int delayMs)
    {
        repeatDelayOverride = delayMs;
        UpdateDelayChecks();
        SaveSettings();
    }

    private void UpdateSpeedChecks()
    {
        if (speedWindowsItem != null) speedWindowsItem.Checked = repeatIntervalOverride == 0;
        if (speed30Item != null) speed30Item.Checked = repeatIntervalOverride == 30;
        if (speed25Item != null) speed25Item.Checked = repeatIntervalOverride == 25;
        if (speed20Item != null) speed20Item.Checked = repeatIntervalOverride == 20;
        if (speed15Item != null) speed15Item.Checked = repeatIntervalOverride == 15;
    }

    private void UpdateDelayChecks()
    {
        if (delayWindowsItem != null) delayWindowsItem.Checked = repeatDelayOverride == 0;
        if (delay400Item != null) delay400Item.Checked = repeatDelayOverride == 400;
        if (delay300Item != null) delay300Item.Checked = repeatDelayOverride == 300;
        if (delay250Item != null) delay250Item.Checked = repeatDelayOverride == 250;
    }

    private void LoadSettings()
    {
        try
        {
            using (RegistryKey key = Registry.CurrentUser.CreateSubKey(AppRegPath))
            {
                object b = key.GetValue("SelectedButton", 2);
                object e = key.GetValue("Enabled", 1);
                object s = key.GetValue("RepeatIntervalOverride", 0);
                object d = key.GetValue("RepeatDelayOverride", 0);

                int parsedButton;
                if (int.TryParse(Convert.ToString(b), out parsedButton) &&
                    (parsedButton == 1 || parsedButton == 2))
                    selectedButton = parsedButton;

                int parsedEnabled;
                if (int.TryParse(Convert.ToString(e), out parsedEnabled))
                    enabled = parsedEnabled != 0;

                int parsedSpeed;
                if (int.TryParse(Convert.ToString(s), out parsedSpeed) &&
                    (parsedSpeed == 0 || parsedSpeed == 30 || parsedSpeed == 25 ||
                     parsedSpeed == 20 || parsedSpeed == 15))
                    repeatIntervalOverride = parsedSpeed;

                int parsedDelay;
                if (int.TryParse(Convert.ToString(d), out parsedDelay) &&
                    (parsedDelay == 0 || parsedDelay == 400 ||
                     parsedDelay == 300 || parsedDelay == 250))
                    repeatDelayOverride = parsedDelay;
            }
        }
        catch
        {
            selectedButton = 2;
            enabled = true;
            repeatIntervalOverride = 0;
            repeatDelayOverride = 0;
        }
    }

    private void SaveSettings()
    {
        try
        {
            using (RegistryKey key = Registry.CurrentUser.CreateSubKey(AppRegPath))
            {
                key.SetValue("SelectedButton", selectedButton, RegistryValueKind.DWord);
                key.SetValue("Enabled", enabled ? 1 : 0, RegistryValueKind.DWord);
                key.SetValue("RepeatIntervalOverride", repeatIntervalOverride, RegistryValueKind.DWord);
                key.SetValue("RepeatDelayOverride", repeatDelayOverride, RegistryValueKind.DWord);
            }
        }
        catch
        {
            // 设置保存失败不影响核心功能
        }
    }

    private static bool IsStartupEnabled()
    {
        try
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(RunRegPath, false))
            {
                if (key == null) return false;
                string value = key.GetValue(RunValueName) as string;
                if (string.IsNullOrEmpty(value)) return false;

                string expected = "\"" + Application.ExecutablePath + "\"";
                return string.Equals(value, expected, StringComparison.OrdinalIgnoreCase);
            }
        }
        catch
        {
            return false;
        }
    }

    private static void SetStartupEnabled(bool value)
    {
        using (RegistryKey key = Registry.CurrentUser.CreateSubKey(RunRegPath))
        {
            if (value)
                key.SetValue(RunValueName, "\"" + Application.ExecutablePath + "\"");
            else
                key.DeleteValue(RunValueName, false);
        }
    }

    protected override void ExitThreadCore()
    {
        StopRepeating();

        if (hookHandle != IntPtr.Zero)
        {
            UnhookWindowsHookEx(hookHandle);
            hookHandle = IntPtr.Zero;
        }

        if (repeatTimer != null)
        {
            repeatTimer.Dispose();
            repeatTimer = null;
        }

        if (trayIcon != null)
        {
            trayIcon.Visible = false;
            trayIcon.Dispose();
        }

        base.ExitThreadCore();
    }

    private delegate IntPtr LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);

    [StructLayout(LayoutKind.Sequential)]
    private struct POINT
    {
        public int x;
        public int y;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct MSLLHOOKSTRUCT
    {
        public POINT pt;
        public uint mouseData;
        public uint flags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct INPUT
    {
        public uint type;
        public KEYBDINPUT ki;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct KEYBDINPUT
    {
        public ushort wVk;
        public ushort wScan;
        public uint dwFlags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWindowsHookEx(
        int idHook, LowLevelMouseProc lpfn, IntPtr hMod, uint dwThreadId);

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool UnhookWindowsHookEx(IntPtr hhk);

    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(
        IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
    private static extern IntPtr GetModuleHandle(string lpModuleName);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(
        uint nInputs, INPUT[] pInputs, int cbSize);

    [DllImport("user32.dll")]
    private static extern void keybd_event(
        byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SystemParametersInfo(
        uint uiAction, uint uiParam, out uint pvParam, uint fWinIni);
}
